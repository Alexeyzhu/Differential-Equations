# Differential-Equations
This is application on Python with use of math, numpy, matplotlib, mpld3 and ipywidgets libraries. There’s one python notebook file Differential equations Assignment.ipynb that contains all the functionality. There’re several functions. Descriptions of all functions are in the *report.pdf*.
